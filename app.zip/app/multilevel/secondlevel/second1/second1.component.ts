import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-second1",
  templateUrl: "./second1.component.html",
  styleUrls: ["./second1.component.sass"],
})
export class Second1Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
